//
//  AIRGoogleMapCircleManager.h
//
//  Created by Nick Italiano on 10/24/16.
//

#ifdef HAVE_GOOGLE_MAPS

#import <React/RCTViewManager.h>

@interface AIRGoogleMapCircleManager : RCTViewManager

@end

#endif
