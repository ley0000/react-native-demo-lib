//
//  AIRGMSPolygon.m
//  AirMaps
//
//  Created by Gerardo Pacheco 02/05/2017.
//

#ifdef HAVE_GOOGLE_MAPS

#import "AIRGMSPolygon.h"

@implementation AIRGMSPolygon

@end

#endif
