//
//  AIRMapUrlTileManager.h
//  AirMaps
//
//  Created by cascadian on 3/19/16.
//  Copyright © 2016. All rights reserved.
//


#import <React/RCTViewManager.h>

@interface AIRMapUrlTileManager : RCTViewManager

@end
