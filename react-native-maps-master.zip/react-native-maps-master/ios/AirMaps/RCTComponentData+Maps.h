//
//  RCTComponentData+Maps.h
//  AirMaps
//
//  Created by Salah Ghanim on 24.12.23.
//  Copyright © 2023 Christopher. All rights reserved.
//

#import <React/RCTComponentData.h>

@interface RCTComponentData (Maps)

@end
