declare module '*.jpg';
declare module '*.png';
