export const PROVIDER_DEFAULT = undefined;
export const PROVIDER_GOOGLE = 'google';
