# Security Policy

## Reporting a Vulnerability

**Please do not report security vulnerabilities through any public method** Instead, please make use of private vulnerability reporting (you can learn how to do so [here](https://docs.github.com/en/code-security/security-advisories/guidance-on-reporting-and-writing/privately-reporting-a-security-vulnerability#privately-reporting-a-security-vulnerability)).
